# Repository eligibility, originality, and scope

## Contents

1. Eligibility gate
2. Evidence collection
3. License handling
4. Originality and public-solution search
5. Authenticity and system-level scope
6. Rejection conditions

## 1. Eligibility gate

Verify the current Olympus program rules supplied by the user. Unless newer rules override them, require:

- public GitHub repository;
- at least 500 stars;
- at least one commit in the preceding 12 months;
- production-quality codebase;
- primary task language among TypeScript, JavaScript, Python, Go, Rust, C++, or Java;
- permissive open-source license explicitly accepted by the program;
- exact pinned commit;
- optional issue URL only when it genuinely describes the work.

Do not infer eligibility from memory. Browse the repository, commit history, license file, and relevant program guidance.

## 2. Evidence collection

Record in author notes, not `problem.md`:

- repository URL and pinned commit;
- current star count and observation date;
- latest qualifying commit date;
- license identifier plus the exact repository license file;
- language and build system;
- relevant issues, PRs, releases, and searches;
- why the feature fits repository goals;
- why the work is not already implemented.

Prefer first-party GitHub pages and repository files. Search web results only to locate primary sources.

## 3. License handling

- Treat “license not recognized” as a real risk, not a cosmetic warning.
- Read the repository license text and compare it with the currently permitted list.
- Reject copyleft, source-available, ambiguous custom, missing, or mixed licensing unless the program explicitly permits it.
- A permissive dependency license does not establish the repository license.
- Do not continue merely because an automated eligibility gate passed with caution.

## 4. Originality and public-solution search

Search:

- repository code and history;
- open and closed issues;
- open, closed, and merged PRs;
- releases and changelogs;
- upstream/downstream sibling projects when they can provide a direct port;
- earlier submitted tasks and supplied reference packages;
- general web results for the proposed API and distinctive behavior.

Classify overlap:

- **Duplicate:** same repository layer, substantially same contract, and readily reusable solution. Reject.
- **Publicly solved core:** public code implements the difficult majority. Reject or redesign.
- **Adjacent:** shares a concept but differs materially in API, semantics, outputs, or architecture. Document the distinction.
- **Minor precursor:** covers a small slice, generally less than a quarter of tested work. May be acceptable if the unsolved core remains substantial.

Do not evade plagiarism detection with renaming. Make the engineering problem genuinely distinct.

## 5. Authenticity and system-level scope

A strong task should require meaningful interaction with existing code. Favor features that combine several of:

- parsing or validation;
- public API integration;
- existing option/configuration semantics;
- state or indexing;
- serialization or command integration;
- concurrency or immutability;
- performance-sensitive query/update behavior;
- multiple existing entry points or consumers.

Avoid forcing arbitrary file count. A cohesive change may live in few files, but the solver should need repository understanding. If the reference solution is an isolated new file with no existing consumers, task-quality review may reject it as insufficiently long-horizon or system-level.

Broaden scope only with a natural consumer: an existing probe path, CLI command, public evaluator, parser pipeline, or configuration surface. Do not bolt on irrelevant integrations to inflate difficulty.

## 6. Rejection conditions

Reject or redesign when any condition holds:

- unclear or unaccepted license;
- stale or low-star repository under current rules;
- core feature already available upstream;
- task depends primarily on copying a public PR;
- feature conflicts with repository direction;
- requirement cannot be tested deterministically offline;
- correctness depends on unspecified English wording;
- performance budget lacks reference headroom;
- task is only a toy algorithm or broad repository-wide refactor;
- fair prompt would need to reveal the solution architecture;
- reference solution cannot meet the full contract cleanly.
