# Verification, false-positive auditing, and packaging

## Contents

1. Clean-state matrix
2. Static and dynamic checks
3. False-positive audit
4. Candidate-pass adjudication
5. Packaging and handoff

## 1. Clean-state matrix

Use isolated checkouts from the pinned commit.

| State | Base mode | New mode |
|---|---|---|
| Test patch only | Pass | Fail for missing/incorrect feature |
| Test + solution | Pass | Pass |

Also run the clean repository’s ordinary tests to identify pre-existing failures before authoring.

For every state:

- apply patches sequentially with `git apply --check` first;
- run from `/app`-equivalent working directory;
- parse the produced XML, not only the process exit code;
- verify every expected test/subtest is classified;
- inspect unexpected `build`, execution, skipped, or missing nodes;
- run repeatedly when performance or concurrency is involved.

## 2. Static and dynamic checks

Static:

- formatting and `git diff --check`;
- prompt UTF-8/ASCII and word limit;
- exact public signatures;
- patch file boundaries;
- test.sh executable mode and argument parsing;
- Docker `FROM`, `/app`, build-only dependency setup, and final command;
- no challenge-internal terminology in patches;
- exact canonical ZIP files.

Dynamic:

- affected package tests and full repository suite;
- race detector on shared/reusable paths;
- language linter/vet/static analysis;
- offline module/package execution;
- repeated deterministic workload;
- patch forward application and inverse application where relevant;
- mutation and pointer/map independence;
- nil, missing object, overflow, deep recursion, and cycle termination;
- all public entry points and named options.

Record commands, versions, counts, durations, and unavailable checks in `verification.md`. Never claim Docker validation when Docker was unavailable.

## 3. False-positive audit

Build an adversarial matrix from the prompt. For each requirement, ask how a plausible solver could cheat accidentally:

- hard-code fixture sizes or paths;
- scan all rules but still pass small tests;
- implement only positive constraints, not exclusions;
- compare numeric text after coercion and collapse distinct values;
- mutate caller-owned options after returning a correct result;
- return aliased pointers/maps;
- use source positions where final target positions are required;
- skip recursion after moving identities;
- handle self-cycles but not entry-dependent mutual cycles;
- pass fixed-depth cases with a recursion limit;
- enumerate a uint64 or unbounded wildcard range one element at a time;
- satisfy wrappers but not the most general public API;
- preserve an option on the single-item path but not grouped/scoped variants;
- meet semantics but exceed the stated workload on representative hardware.

Create a focused mutant or probe only for behavior already documented. A valid demonstrated gap must satisfy:

1. broken implementation is plausible;
2. original suite passes completely;
3. focused probe passes reference;
4. probe fails broken implementation;
5. requirement is stated or clearly discoverable;
6. new assertion does not prescribe internals.

After adding the test, rerun fairness and historical passing candidates. Do not indiscriminately adopt an auditor’s replacement patch; inspect each proposed case.

## 4. Candidate-pass adjudication

Do not accept a green JUnit report automatically.

Inspect:

- baseline and feature XML counts;
- test or patch modifications;
- production diff size and file scope;
- environment/test-name detection;
- suspicious constants or workload shortcuts;
- algorithmic complexity;
- concurrency and mutation behavior;
- prompt-permitted edge cases outside the verifier.

Run focused probes against candidate and reference in isolated worktrees. A discriminator is fair only when the prompt or visible repository requires the behavior. Divergence at an unspecified implementation boundary is not a false positive.

Performance adjudication:

- run candidate and reference on the same idle machine;
- repeat at least three times;
- distinguish marginal hardware variance from an order-of-magnitude algorithmic gap;
- if official hardware passed but representative hardware narrowly missed, treat confidence cautiously;
- increase a limit only when the candidate genuinely meets the intended complexity and the threshold is overly hardware-sensitive.

## 5. Packaging and handoff

Require exactly the canonical eight files unless the current program specifies otherwise. Keep them at ZIP root.

Before packaging:

- validate the directory;
- verify solution and test patches are final versions;
- ensure documentation counts match the final test patch;
- confirm no temporary XML, build outputs, toolchains, solver patches, or analysis folders are included;
- create a deterministic ZIP;
- list archive entries and compute SHA-256;
- reopen or extract the ZIP and rerun structural validation.

Handoff should state:

- final ZIP path and checksum;
- files changed by the last revision;
- verification matrix outcome;
- calibration result separated by patch version;
- whether historical passing agents still logically pass;
- any unexecuted limitation.
