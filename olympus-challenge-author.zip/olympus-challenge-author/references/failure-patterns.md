# Recurring failure patterns and remedies

## Contents

1. Prompt and fairness
2. Harness and JUnit
3. Docker and environment
4. Solution and false positives
5. Calibration and review

## 1. Prompt and fairness

| Failure | Cause | Remedy |
|---|---|---|
| Hidden edge rule unfair | Exact grammar/phase/order absent from prompt and repository | Add behavioral wording or relax the test |
| Description too spec-like | Internal derivations, field paths, or redundant preservation prose | Keep observable rule; remove implementation narration |
| Description too broad | “Every form,” unlimited precision, or repository-wide promises exceed coverage | Scope to concrete syntaxes and tested behavior |
| Description leakage | Workload construction, test count, checksum, or test names exposed | State only public scale and semantics |
| Built-in override ambiguity | Tests assume user definition replaces built-in without stating precedence | State replacement rule or remove assertion |
| Compile/runtime phase mismatch | Test pins rejection during compile but prompt only says reject | State phase explicitly or accept runtime error |
| Exact output over-pinned | Several valid patches/orders exist | Apply result and check constrained counts/categories |
| Aggregate timeout unfair | Whole suite shares workload’s budget | Isolate and time only documented workload |

## 2. Harness and JUnit

| Failure | Cause | Remedy |
|---|---|---|
| Boolean flag misuse | `-test.v=test2json` passed to boolean flag | Use `-test.v` and pipe to `go tool test2json` |
| VCS status error | Extracted checkout lacks usable Git metadata | Add `-buildvcs=false` to Go build/test commands |
| New tests excluded | Regex misses a pluralized or differently prefixed test family | Enumerate/run regex against actual names before packaging |
| Unexpected build testcase | Build failure not classified as expected missing API | Parse compiler output narrowly and emit skipped build node only for absent requested API |
| Missing tests after panic | Converter suppresses package/process diagnostic because a testcase already failed | Preserve abnormal exit output and keep conservative missing-test failures |
| Ordinary failure duplicated | Every package `fail` becomes execution error | Add execution node only for abnormal/interrupted status, not normal status 1 |
| Harness self-tests called unfair | Internal converter tests appear in agent-facing patch without prompt support | Validate harness separately; keep feature patch focused |
| Static mode-support failure | Helper built before `base/new` branch | Build helper inside selected branch |
| Non-executable test.sh | Patch records mode `100644` | Set Git mode `100755` and verify patch header |
| Race performance flake | Timed workload runs under `-race` | Separate race and performance invocations |

## 3. Docker and environment

| Failure | Cause | Remedy |
|---|---|---|
| Wrong workdir | Uses `/workspace` while evaluator patches/runs in `/app` | Set `WORKDIR /app` |
| Unsupported base image | Generic or unrecognized image | Use current language-specific Olympus image |
| Offline runtime failure | Dependencies downloaded only when tests run | Download/install during Docker build |
| Build-time tests | `RUN go test`, `pytest`, `npm test`, etc. | Build/cache only; test after patches at runtime |
| Weak layer cache | Entire repo copied before dependency manifest | Copy manifests first when repository layout permits |
| Missing go.sum warning | Reproducibility cannot be confirmed | Verify committed `go.mod` and `go.sum` |
| Remote image EOF | Build service disconnects before Docker steps | Retry infrastructure; do not rewrite Dockerfile without Docker evidence |

## 4. Solution and false positives

| Failure | Cause | Remedy |
|---|---|---|
| Tests pass but prompt edge fails | Suite omitted a plausible supported form | Add a fair focused probe and fix reference |
| Nontermination on wildcard exclusion | Algorithm enumerates huge numeric core range | Model intervals/events or bound advancement analytically |
| Caller-owned filters mutate | Only outputs checked | Snapshot text and option flags around every public API |
| Returned values alias | Later mutation corrupts cached results | Test pointer/map identity and later calls |
| Lazy snapshot access | Only root mutation tested | Mutate/remove descendant objects and backing blobs after construction |
| Reference-only overflow semantics | Prompt allows multiple intermediate representations | Do not flag candidate unless final behavior is specified |
| Candidate barely meets time on fast runner | Grossly inefficient algorithm hidden by hardware | Compare repeated candidate/reference runs on same machine |
| Opaque checksum fairness failure | Test pins undisclosed encoding of results | Assert direct relations or derive oracle transparently |

## 5. Calibration and review

| Failure | Cause | Remedy |
|---|---|---|
| Legitimate pass called false positive | Reviewer uses unspecified discriminator | Contest with prompt/test evidence and same-machine results |
| Pass later overturned | Initial review trusted green suite only | Perform adversarial candidate audit before declaring safe |
| Difficulty changes after fairness fix | Tests removed a hidden trap | Recalibrate; do not reintroduce unfairness |
| Many failures after panic | Missing tests counted as independent defects | Isolate tests and identify one root interruption |
| Historical pass considered stale | Prompt or feature tests revised | Separate formal cohort; rerun candidate patch if possible |
| Repeated checks waste budget | Known static issues left until late | Run validator and review checklist before uploading |
| Plagiarism service error | Check could not complete, no similarity verdict | Retry; bypass only when policy explicitly permits infrastructure errors |
