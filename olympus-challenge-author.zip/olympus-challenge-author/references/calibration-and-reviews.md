# Calibration, solver-run analysis, and review revisions

## Contents

1. Blind calibration protocol
2. Verdict taxonomy
3. Closeness analysis
4. Pass-rate interpretation
5. Revision strategy
6. Model-specific patterns

## 1. Blind calibration protocol

For each run:

- start from an isolated pinned checkout;
- apply only `test.patch` before the solver starts;
- give the solver `problem.md`, repository, and normal tool access;
- hide `solution.patch`, test source details, author notes, previous trajectories, and suspected bugs;
- prevent solver edits to evaluator tests from counting;
- run baseline and feature suites after completion;
- save evaluation JSON, baseline/new JUnit, solution diff, trajectory, and test log.

Count a pass only when:

- baseline passes;
- every feature test passes;
- no test/harness tampering occurred;
- no hidden answer or fixture leakage was used;
- no environment blocker explains the result;
- focused false-positive review finds no fair candidate-only defect.

## 2. Verdict taxonomy

- **Legitimate pass:** complete behavior and no fair discriminator.
- **Genuine solver failure:** environment healthy; one or more documented behaviors fail.
- **System/environment issue:** dependency, permission, machine, service, or harness failure prevents meaningful evaluation.
- **Test broken:** verifier cannot compile/run independently of solver behavior, such as symbol collisions or malformed flags.
- **Test mismatch/unfair:** candidate follows a reasonable prompt interpretation but hidden test requires an unstated distinction.
- **False positive:** suite passes, but a fair prompt-required probe fails candidate and passes reference.
- **Infrastructure retry:** plagiarism/model/check service returns no substantive verdict because of transient EOF/unavailable errors.

Do not call a failed run a false positive. False positives are undeserved passes.

## 3. Closeness analysis

Report both record count and logical root defects.

Parent and subtest failures often describe one defect. A panic may cause dozens of wrapper-generated missing-test failures. Explain:

- baseline pass count;
- feature pass/fail/error count;
- root causes;
- which major subsystems succeeded;
- whether workload completed;
- whether the fix is local, multi-part, or architectural;
- elapsed work time and patch size when informative.

Examples:

- `85/87` with one group-level `Equivalent` omission is extremely close.
- `27/87` after a panic may actually implement most behavior; rerun isolated groups before judging.
- `52 missing` after `Rationalize` panic is one root interruption, not 52 independent semantic defects.
- a correct output that takes 50x the reference time can still violate an explicit performance contract.

## 4. Pass-rate interpretation

- Keep calibration cohorts separate by prompt/test patch version when formal rules require fresh runs.
- Use historical legitimate passes as solvability and regression evidence, not necessarily as fresh count.
- Do not estimate a stable rate from one or two samples.
- A 1/3 interim rate can still converge below 3/10; continue the planned cohort.
- Repeated near-misses on different documented behaviors demonstrate legitimate breadth.
- Repeated identical failures may justify a prompt clarification only if the wording is genuinely ambiguous.
- If ten fresh runs produce zero passes but several are one small documented fix away, consider a subtle behavioral clarification before weakening tests.
- If more than the allowed band pass, harden with additional authentic interactions or scale, not arbitrary traps.

## 5. Revision strategy

Classify changes by calibration impact:

- **Behavioral prompt change:** fresh calibration normally required; may change difficulty.
- **Feature test change:** fresh calibration required; rerun historical passing patches where available.
- **Reference solution change only:** verify suite and false-positive probes; solver difficulty may be unchanged.
- **Harness diagnostics/control-flow only:** behavior and difficulty unchanged, though the platform may demand fresh runs.
- **Docker/cache/documentation only:** generally no solver behavior impact; still rebuild/revalidate affected checks.

When revising:

1. make the smallest change;
2. state exactly which files changed;
3. rerun static/fairness checks;
4. rerun clean matrix;
5. verify historical legitimate passes logically or actually;
6. package a new ZIP and checksum;
7. treat new formal calibration separately.

## 6. Model-specific patterns

Use these only as observed tendencies, never hidden requirements:

- **Terra low:** useful early difficulty screen; may fail broad integration quickly.
- **Terra high/xhigh:** useful feasibility check and architecture signal; a pass can indicate the task needs more authentic depth.
- **Nova:** capable of long production patches, but run variation is high. Common misses include one option path, fallback family, wildcard semantics, final-path scoping, or accidental quadratic behavior.
- **Orion:** often stronger at completing detailed contracts but can share architecture mistakes around boundary ordering, wildcard families, or formatter/parser interactions.
- **Vega:** can reach efficient architecture with fewer steps, but may make a concise conceptual misread such as option precedence or token-type semantics.

Do not write prompts targeted to a model’s private reasoning. Clarify only public behavior.
