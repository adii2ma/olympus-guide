# Tests, harness, Dockerfile, and golden solution

## Contents

1. Test-patch contract
2. Behavioral suite design
3. Harness requirements
4. JUnit conversion
5. Dockerfile requirements
6. Golden solution rules

## 1. Test-patch contract

`test.patch` should resemble a real repository PR containing tests and test infrastructure only.

Require:

- valid unified Git diff;
- clean application to the pinned commit;
- deterministic offline tests;
- no production solution code;
- no unrelated reformatting;
- no files or comments named `challenge`, `quest`, `olympus`, `mars`, or other program-internal terms;
- executable `test.sh` mode `100755`;
- no dependency installation in `test.sh`;
- no hidden implementation inspection;
- no exact diagnostic wording unless specified or a visible repository convention.

Generate from the clean repository with `git diff --binary`. Verify the patch after generation rather than trusting the working tree.

## 2. Behavioral suite design

Test through public APIs and independently observable effects. Cover:

- representative core success;
- every precedence and fallback branch;
- empty, missing, duplicate, malformed, boundary, and typed cases;
- nested and final-path behavior;
- all named existing options and entry points;
- repeated calls, independent results, mutation, reset, and reuse;
- concurrent reads or option reuse where specified;
- construction and deferred-access errors;
- deterministic generated or exhaustive small-domain oracles;
- large workload with direct semantic validation.

Strong assertions include:

- applying a generated patch and comparing the final value;
- checking membership of returned witnesses against the original predicates;
- deriving minimal move counts using an independent LIS oracle;
- comparing fallback output with the repository’s ordinary algorithm;
- verifying inputs and filters remain unchanged;
- mutating one returned pointer/map and confirming later results are independent.

Avoid asserting:

- one arbitrary valid operation sequence;
- hidden checksum constants;
- internal data structures;
- exact error strings;
- unspecified ordering;
- a compile/runtime error phase not stated or established;
- performance shapes absent from the prompt.

## 3. Harness requirements

Support exactly:

```bash
./test.sh --output_path results.xml base
./test.sh --output_path results.xml new
```

Base mode:

- run genuine existing tests for the affected area, often the full package or repository suite;
- exclude only documented network/flaky failures already present at the base;
- pass with `test.patch` applied and no solution;
- write parseable JUnit for tests and build failures.

New mode:

- run all feature tests and subtests, with no accidental regex omission;
- fail without `solution.patch` because the feature is absent or incorrect;
- pass with the reference solution;
- avoid fail-fast so all reachable failures are reported;
- keep the timed workload isolated from ordinary functional tests;
- run race checks separately from performance measurement.

Build the JUnit converter only after selecting the mode. Static sanity checkers may reject a helper build placed before mode branching even though the test patch provides the helper.

Compile outside the performance deadline. Use `-buildvcs=false` when extracted repositories lack usable VCS metadata. Pass `-test.v` or `-test.v=true`; never pass a string to the boolean flag.

## 4. JUnit conversion

Convert every test/subtest and build error into stable JUnit. Preserve:

- failure versus error versus skipped status;
- test and package output after XML-invalid rune cleaning;
- package/process diagnostics for abnormal termination even when an earlier testcase failed;
- a conservative nonzero exit when tests are missing;
- ordinary status-1 assertion failures without an extra unexpected execution testcase.

Do not put harness-maintenance unit tests into the agent-facing patch when their behavior is absent from the challenge prompt and repository. Validate the converter separately with synthetic event streams.

When a process panics, distinguish the root panic/error from outer wrapper “missing test” records. Missing records are fallout, not independent semantic defects.

## 5. Dockerfile requirements

Use the currently required language image. Known Olympus images include:

| Language | Base image |
|---|---|
| Python | `public.ecr.aws/d3j8x8q7/olympus-base-python:latest` |
| TypeScript/JavaScript | `public.ecr.aws/d3j8x8q7/olympus-base-typescript:latest` |
| Go | `public.ecr.aws/d3j8x8q7/olympus-base-go:latest` |
| Rust | `public.ecr.aws/d3j8x8q7/olympus-base-rust:latest` |
| Java/JVM | `public.ecr.aws/d3j8x8q7/olympus-base-jvm:latest` |
| C++ | `public.ecr.aws/d3j8x8q7/olympus-base-cpp:latest` |

Accept a newer program-provided image over this table.

Require:

- first instruction is an allowed `FROM`;
- `WORKDIR /app`;
- dependencies installed/downloaded during build because runtime uses `--network none`;
- repository copied into `/app`;
- a compile/build-cache population step when appropriate;
- no test command in a `RUN` instruction;
- Dockerfile works before either patch is applied;
- final instruction `CMD ["/bin/bash"]`.

For Go caching, prefer copying `go.mod` and `go.sum`, downloading modules, then copying source, but only when both files exist. Do not disable checksum verification during dependency download. Runtime may set `GOPROXY=off` after dependencies are cached.

## 6. Golden solution rules

`solution.patch` is proof of solvability. Require:

- all prompt requirements, including low-frequency combinations;
- no regressions;
- existing repository patterns and formatting;
- production changes only;
- no tests, test harness, generated artifacts, or unrelated cleanup;
- no unused public API;
- no implementation that special-cases hidden fixtures;
- reasonable algorithmic complexity with reference headroom;
- clear error values/types without exact prose coupling.

Audit the solution beyond verifier success. Probe prompt-permitted inputs omitted from tests. If the reference violates the prompt but passes tests, fix both fairly before calibration.
