# Task design, difficulty, and prompt authoring

## Contents

1. Design from observable behavior
2. Construct legitimate difficulty
3. Requirement-to-test matrix
4. Write `problem.md`
5. Performance contracts
6. Description-quality review

## 1. Design from observable behavior

Start with one sentence describing the user-visible capability. Then specify:

- public entry points and types;
- accepted inputs and validation phase;
- result semantics;
- precedence and ordering;
- missing, empty, duplicate, null, or invalid cases;
- interaction with existing options and entry points;
- mutation, aliasing, reset, and concurrency guarantees;
- error behavior without exact prose;
- performance scale if load-bearing;
- explicit non-goals only when they prevent a plausible scope expansion.

Every sentence should either change an observable result, define accepted input, establish an error boundary, or state a measurable quality constraint.

## 2. Construct legitimate difficulty

Target the requested blind pass band, commonly 1–3 of 10, through a coherent combination of:

- per-attribute or per-item precedence rather than one global winner;
- final-path versus source-path behavior after reordering;
- dynamic scopes or wildcard bindings;
- exact minimality or canonical selection with an independently derivable oracle;
- recursive expansion with cycles and deep chains;
- interactions with existing options such as equivalence, inversion, rationalization, filtering, or ignores;
- snapshot immutability and independent returned values;
- concurrency-safe reusable configuration;
- input sizes that reject accidental quadratic algorithms while leaving large reference headroom;
- overflow, boundary, and typed-value semantics that naturally follow the domain.

Do not use:

- undocumented test-only rules;
- arbitrary magic checksums;
- exact operation order when only a count/result is specified;
- sleeps, randomness, network access, or fragile microbenchmarks;
- intentionally misleading examples;
- obscure malformed inputs irrelevant to normal repository use;
- a global timeout covering unrelated tests when the prompt times one workload.

Difficulty should survive a clearer prompt. If one clarifying sentence makes the task trivial, the task lacks engineering depth.

## 3. Requirement-to-test matrix

Before coding, maintain a private matrix with columns:

| Requirement | Prompt sentence | Public observation | Baseline behavior | Positive tests | Negative/adversarial tests | Reference path |
|---|---|---|---|---|---|---|

Rules:

- No test without a prompt sentence or strong visible repository convention.
- No prompt requirement without at least one meaningful test unless it is an explicit non-goal.
- Cover interactions, not only isolated features.
- Track false-positive mutants: plausible broken implementations that must fail.
- Do not expose the matrix or test names in `problem.md`.

## 4. Write `problem.md`

Use natural maintainer-style prose. A strong order is:

1. task opening and public API;
2. core behavior;
3. precedence/fallback;
4. advanced interactions;
5. edge cases and validation;
6. performance requirement;
7. narrow scope exclusions if necessary.

Keep it behavioral:

- Say “later input mutation must not affect results,” not “deep-copy every field.”
- Say “round half-to-even,” not a multi-step internal arithmetic derivation unless intermediate order changes output.
- Name compile-time versus runtime errors only when tests distinguish the phase.

Remove:

- target repository and commit metadata;
- solver or model names;
- desired pass rates;
- test count, test names, checksum, seeds, fixtures, and harness details;
- “do not break existing behavior” boilerplate;
- “do not add other APIs” unless extra APIs change compatibility or are explicitly forbidden;
- exact English error messages;
- internal field paths when behavior-first wording works;
- broad promises beyond tested/discoverable behavior.

Formatting:

- Use UTF-8; enforce ASCII when the platform check requires it.
- Prefer paragraphs over one sentence per line.
- Stay below a supplied word limit; 500 words is a useful default for dense tasks.
- Use code fences only for public signatures or indispensable examples.
- Avoid Unicode punctuation when ASCII-only validation is active.

## 5. Performance contracts

State:

- which public operation is timed;
- total calls or elements;
- relevant structural shape, such as wide sibling scopes, deep nesting, or dynamic endpoints;
- whether construction is included;
- a single wall-clock budget.

Keep fixture generation, compilation, race instrumentation, and result validation outside the timed interval unless explicitly part of the contract. Time only the announced workload. Validate semantic outputs or independently derived counts; do not publish an arbitrary checksum.

Reference guidance:

- Aim for at least 5x headroom, preferably 10x or more.
- Repeat on an idle representative machine.
- If the reference is close to the threshold, optimize the reference or relax the budget.
- Do not change the threshold simply because one grossly inefficient solver nearly passes.

## 6. Description-quality review

For each automated suggestion, ask:

1. Does the text define behavior a reasonable solver cannot discover?
2. Does removing it make a tested distinction ambiguous?
3. Is it implementation strategy rather than observable behavior?
4. Is it redundant with a preceding rule?
5. Does it overclaim beyond tests and visible repository semantics?

Fix high-severity valid comments. Apply easy wording cleanup when it does not weaken fairness. Contest only when the proposed removal would make a hidden test undiscoverable or contradict the repository, and cite concrete evidence.
