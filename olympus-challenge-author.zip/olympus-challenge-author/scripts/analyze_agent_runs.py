#!/usr/bin/env python3
"""Summarize Olympus agent-run directories and ZIP bundles."""

from __future__ import annotations

import argparse
import io
import json
import re
import sys
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Callable
from xml.etree import ElementTree


@dataclass
class RunSummary:
    source: str
    run: str
    verdict: str
    baseline_passed: bool | None
    new_passed: bool | None
    baseline_tests: int | None
    baseline_failures: int | None
    baseline_errors: int | None
    new_tests: int | None
    new_failures: int | None
    new_errors: int | None
    logical_failures: list[str]
    missing_records: int
    duration_seconds: float | None
    solution_loc: int | None
    summary: str
    environment_blocker: bool | None


def parse_int(value: str | None) -> int | None:
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None


def xml_summary(data: bytes) -> tuple[int | None, int | None, int | None, list[str], int]:
    try:
        root = ElementTree.fromstring(data)
    except ElementTree.ParseError:
        return None, None, None, ["<malformed JUnit XML>"], 0
    tests = parse_int(root.get("tests"))
    failures = parse_int(root.get("failures"))
    errors = parse_int(root.get("errors"))
    if tests is None:
        suites = root.findall(".//testsuite") if root.tag != "testsuite" else [root]
        tests = sum(parse_int(suite.get("tests")) or 0 for suite in suites)
        failures = sum(parse_int(suite.get("failures")) or 0 for suite in suites)
        errors = sum(parse_int(suite.get("errors")) or 0 for suite in suites)
    records: list[tuple[str, str]] = []
    missing = 0
    for case in root.findall(".//testcase"):
        problem = case.find("failure") or case.find("error")
        if problem is None:
            continue
        name = case.get("name", "<unnamed>")
        message = problem.get("message", "")
        records.append((name, message))
        if "missing" in message.lower() and "junit" in message.lower():
            missing += 1
    names = [name for name, _ in records]
    leaves = [name for name in names if not any(other.startswith(name + "/") for other in names)]
    return tests, failures, errors, sorted(dict.fromkeys(leaves)), missing


def parse_timestamp(value: object) -> datetime | None:
    if not isinstance(value, str):
        return None
    normalized = value.replace("Z", "+00:00")
    for parser in (
        lambda: datetime.fromisoformat(normalized),
        lambda: datetime.strptime(value, "%m/%d/%Y %H:%M:%S"),
        lambda: datetime.strptime(value, "%d-%m-%Y %H:%M:%S"),
    ):
        try:
            return parser()
        except ValueError:
            pass
    return None


def trajectory_duration(data: bytes) -> float | None:
    try:
        document = json.loads(data)
        steps = document.get("steps", [])
        if not steps:
            return None
        start = parse_timestamp(steps[0].get("timestamp"))
        end = parse_timestamp(steps[-1].get("timestamp"))
        if start and end:
            return max(0.0, (end - start).total_seconds())
    except (json.JSONDecodeError, AttributeError, TypeError):
        pass
    return None


def extract_loc(data: bytes) -> int | None:
    match = re.search(rb"sandbox LOC:\s*(\d+)", data)
    return int(match.group(1)) if match else None


def summarize(
    source: str,
    run: str,
    read: Callable[[str], bytes | None],
) -> RunSummary:
    raw_eval = read("eval-result.json") or b"{}"
    try:
        evaluation = json.loads(raw_eval)
    except json.JSONDecodeError:
        evaluation = {}
    results = evaluation.get("test_results", {})
    environment = evaluation.get("environment_assessment", {})
    baseline = xml_summary(read("junit-baseline.xml") or b"")
    new = xml_summary(read("junit-new.xml") or b"")
    duration = trajectory_duration(read("trajectory.json") or b"")
    loc = extract_loc(read("test-log.txt") or b"")
    summary = evaluation.get("quick_failure_summary") or evaluation.get("summary") or ""
    blocker = environment.get("blocker_detected")
    return RunSummary(
        source=source,
        run=run or Path(source).stem,
        verdict=str(evaluation.get("verdict", "UNKNOWN")),
        baseline_passed=results.get("baseline_passed"),
        new_passed=results.get("new_tests_passed"),
        baseline_tests=baseline[0],
        baseline_failures=baseline[1],
        baseline_errors=baseline[2],
        new_tests=new[0],
        new_failures=new[1],
        new_errors=new[2],
        logical_failures=new[3],
        missing_records=new[4],
        duration_seconds=duration,
        solution_loc=loc,
        summary=str(summary),
        environment_blocker=blocker if isinstance(blocker, bool) else None,
    )


def summaries_from_directory(path: Path) -> list[RunSummary]:
    evals = sorted(path.rglob("eval-result.json")) if path.is_dir() else []
    if path.is_file() and path.name == "eval-result.json":
        evals = [path]
    output: list[RunSummary] = []
    for eval_path in evals:
        root = eval_path.parent

        def read(name: str, root: Path = root) -> bytes | None:
            candidate = root / name
            try:
                return candidate.read_bytes()
            except OSError:
                return None

        output.append(summarize(str(path), root.name, read))
    return output


def summaries_from_zip(path: Path) -> list[RunSummary]:
    output: list[RunSummary] = []
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        roots = sorted(
            str(PurePosixPath(name).parent)
            for name in names
            if PurePosixPath(name).name == "eval-result.json"
        )
        for root in roots:
            prefix = "" if root == "." else root.rstrip("/") + "/"

            def read(name: str, prefix: str = prefix) -> bytes | None:
                member = prefix + name
                if member not in names:
                    return None
                try:
                    return archive.read(member)
                except (KeyError, RuntimeError):
                    return None

            run = PurePosixPath(root).name if root != "." else path.stem
            output.append(summarize(str(path), run, read))
    return output


def load(path: Path) -> list[RunSummary]:
    if path.is_file() and zipfile.is_zipfile(path):
        return summaries_from_zip(path)
    return summaries_from_directory(path)


def format_duration(seconds: float | None) -> str:
    if seconds is None:
        return "-"
    minutes, remainder = divmod(int(seconds), 60)
    return f"{minutes}m{remainder:02d}s"


def print_table(runs: list[RunSummary]) -> None:
    columns = ("RUN", "VERDICT", "BASE", "NEW", "LOGICAL", "DURATION", "LOC")
    rows: list[tuple[str, ...]] = []
    for run in runs:
        base = f"{run.baseline_tests or '-'}:{run.baseline_failures or 0}F/{run.baseline_errors or 0}E"
        new = f"{run.new_tests or '-'}:{run.new_failures or 0}F/{run.new_errors or 0}E"
        rows.append(
            (
                run.run,
                run.verdict,
                base,
                new,
                str(len(run.logical_failures)),
                format_duration(run.duration_seconds),
                str(run.solution_loc or "-"),
            )
        )
    widths = [max(len(columns[i]), *(len(row[i]) for row in rows)) for i in range(len(columns))]
    print("  ".join(columns[i].ljust(widths[i]) for i in range(len(columns))))
    print("  ".join("-" * width for width in widths))
    for row in rows:
        print("  ".join(row[i].ljust(widths[i]) for i in range(len(columns))))
    for run in runs:
        print(f"\n{run.run}: {run.summary or run.verdict}")
        if run.logical_failures:
            print("  logical failing leaves: " + ", ".join(run.logical_failures))
        if run.missing_records:
            print(f"  cascading missing-test records: {run.missing_records}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--json", action="store_true", dest="json_output")
    args = parser.parse_args()
    runs: list[RunSummary] = []
    for path in args.inputs:
        runs.extend(load(path.resolve()))
    if not runs:
        print("No eval-result.json artifacts found.", file=sys.stderr)
        return 1
    if args.json_output:
        print(json.dumps([asdict(run) for run in runs], indent=2))
    else:
        print_table(runs)
    return 0


if __name__ == "__main__":
    sys.exit(main())
