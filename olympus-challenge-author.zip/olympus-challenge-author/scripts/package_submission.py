#!/usr/bin/env python3
"""Validate and create a deterministic root-level Olympus submission ZIP."""

from __future__ import annotations

import argparse
import hashlib
import sys
import zipfile
from pathlib import Path

from validate_submission import CANONICAL_FILES, validate


def write_deterministic_zip(package: Path, output: Path) -> str:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(CANONICAL_FILES):
            data = (package / name).read_bytes()
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 & 0xFFFF) << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return hashlib.sha256(output.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--allow-unicode", action="store_true")
    parser.add_argument("--max-problem-words", type=int, default=500)
    parser.add_argument("--allow-warnings", action="store_true")
    args = parser.parse_args()

    package = args.package.resolve()
    issues = validate(
        package,
        args.repo.resolve() if args.repo else None,
        ascii_only=not args.allow_unicode,
        max_words=args.max_problem_words,
    )
    errors = [issue for issue in issues if issue.severity == "error"]
    warnings = [issue for issue in issues if issue.severity == "warning"]
    for issue in issues:
        print(f"{issue.severity.upper():7} {issue.code}: {issue.message}", file=sys.stderr)
    if errors or (warnings and not args.allow_warnings):
        reason = "errors" if errors else "warnings (pass --allow-warnings after review)"
        print(f"Refusing to package due to {reason}.", file=sys.stderr)
        return 1

    digest = write_deterministic_zip(package, args.output.resolve())
    print(f"ZIP: {args.output.resolve()}")
    print(f"SHA256: {digest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
