#!/usr/bin/env python3
"""Static and patch-application checks for an Olympus submission package."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path


CANONICAL_FILES = (
    "problem.md",
    "test.patch",
    "solution.patch",
    "Dockerfile",
    "README.md",
    "test-design.md",
    "author-notes.md",
    "verification.md",
)

ALLOWED_BASES = {
    "public.ecr.aws/x8v8d7g8/mars-base:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base-python:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base-typescript:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base-go:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base-rust:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base-jvm:latest",
    "public.ecr.aws/d3j8x8q7/olympus-base-cpp:latest",
}

FORBIDDEN_PATCH_TERMS = re.compile(r"(?i)\b(challenge|quest|olympus|mars|shipd)\b")
RUN_TEST_COMMAND = re.compile(
    r"(?i)\b(go\s+test|pytest|python\s+-m\s+pytest|npm\s+(run\s+)?test|"
    r"pnpm\s+(run\s+)?test|yarn\s+test|cargo\s+test|mvn\s+test|"
    r"gradle\s+test|ctest)\b"
)


@dataclass(frozen=True)
class Issue:
    severity: str
    code: str
    message: str


def add(issues: list[Issue], severity: str, code: str, message: str) -> None:
    issues.append(Issue(severity, code, message))


def read_utf8(path: Path, issues: list[Issue]) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        add(issues, "error", "utf8", f"{path.name} is not valid UTF-8: {exc}")
    except OSError as exc:
        add(issues, "error", "read", f"cannot read {path.name}: {exc}")
    return ""


def changed_paths(patch: str) -> list[str]:
    paths: list[str] = []
    for line in patch.splitlines():
        match = re.match(r"^diff --git a/(.+) b/(.+)$", line)
        if match:
            paths.append(match.group(2))
    return paths


def added_lines(patch: str) -> list[str]:
    return [
        line[1:]
        for line in patch.splitlines()
        if line.startswith("+") and not line.startswith("+++")
    ]


def is_test_related(path: str) -> bool:
    lower = path.lower()
    name = Path(lower).name
    return (
        "testdata/" in lower
        or "/tests/" in f"/{lower}"
        or lower.startswith("tests/")
        or lower.startswith("internal/test2junit/")
        or name == "test.sh"
        or "_test." in name
        or name.startswith("test_")
        or name.endswith(".snap")
        or name.endswith(".golden")
    )


def check_problem(
    package: Path,
    issues: list[Issue],
    ascii_only: bool,
    max_words: int,
) -> None:
    text = read_utf8(package / "problem.md", issues)
    if not text.strip():
        add(issues, "error", "problem-empty", "problem.md is empty")
        return
    if ascii_only:
        for index, char in enumerate(text):
            if ord(char) > 127:
                add(
                    issues,
                    "error",
                    "problem-non-ascii",
                    f"problem.md contains non-ASCII U+{ord(char):04X} at index {index}",
                )
                break
    words = re.findall(r"\S+", text)
    if max_words > 0 and len(words) > max_words:
        add(
            issues,
            "error",
            "problem-length",
            f"problem.md has {len(words)} words; limit is {max_words}",
        )
    leakage = re.compile(
        r"(?i)\b(hidden tests?|test\.patch|solution\.patch|nova|orion|terra|vega|"
        r"pass rate|blind solve|olympus)\b"
    )
    found = sorted(set(match.group(0) for match in leakage.finditer(text)))
    if found:
        add(
            issues,
            "warning",
            "problem-leakage",
            "problem.md contains possible evaluator/calibration language: " + ", ".join(found),
        )


def check_dockerfile(package: Path, issues: list[Issue]) -> None:
    text = read_utf8(package / "Dockerfile", issues)
    meaningful = [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#")]
    if not meaningful:
        add(issues, "error", "docker-empty", "Dockerfile is empty")
        return
    first = meaningful[0]
    if not first.startswith("FROM "):
        add(issues, "error", "docker-from", "first Dockerfile instruction must be FROM")
    else:
        image = first[5:].split()[0]
        if image not in ALLOWED_BASES:
            add(issues, "error", "docker-image", f"unrecognized Olympus base image: {image}")
    if not re.search(r"(?m)^\s*WORKDIR\s+/app\s*$", text):
        add(issues, "error", "docker-workdir", "Dockerfile must set WORKDIR /app")
    if not any(re.match(r"^COPY\s+\.\s+\.\s*$", line, re.I) for line in meaningful):
        add(issues, "warning", "docker-copy", "Dockerfile does not contain COPY . .")
    for line in meaningful:
        if line.upper().startswith("RUN ") and RUN_TEST_COMMAND.search(line):
            add(issues, "error", "docker-tests", f"Dockerfile runs tests during build: {line}")
    if re.search(r"(?i)(test\.patch|solution\.patch)", text):
        add(issues, "error", "docker-patches", "Dockerfile must work without patch files")
    if meaningful[-1] != 'CMD ["/bin/bash"]':
        add(issues, "error", "docker-cmd", 'Dockerfile must end with CMD ["/bin/bash"]')


def check_patch(package: Path, filename: str, issues: list[Issue]) -> None:
    path = package / filename
    patch = read_utf8(path, issues)
    if not patch.strip():
        add(issues, "error", f"{filename}-empty", f"{filename} is empty")
        return
    if "diff --git " not in patch:
        add(issues, "error", f"{filename}-format", f"{filename} is not a Git diff")
        return
    paths = changed_paths(patch)
    if not paths:
        add(issues, "error", f"{filename}-paths", f"{filename} contains no changed paths")
    for changed in paths:
        if FORBIDDEN_PATCH_TERMS.search(changed):
            add(issues, "error", "patch-leak-path", f"program-internal term in patch path: {changed}")
    for line in added_lines(patch):
        if FORBIDDEN_PATCH_TERMS.search(line):
            add(issues, "error", "patch-leak-content", f"program-internal term in added line: {line[:120]}")
            break

    if filename == "test.patch":
        if "test.sh" not in paths:
            add(issues, "error", "test-runner", "test.patch does not add or modify test.sh")
        if "--output_path" not in patch or not re.search(r"\bbase\b", patch) or not re.search(r"\bnew\b", patch):
            add(issues, "error", "test-modes", "test.sh patch does not visibly support --output_path and base/new")
        test_section = re.search(
            r"diff --git a/test\.sh b/test\.sh(?P<body>.*?)(?=\ndiff --git |\Z)",
            patch,
            re.S,
        )
        if test_section and not re.search(r"(?:new file mode|new mode) 100755", test_section.group("body")):
            add(issues, "error", "test-mode", "test.sh is not recorded as mode 100755")
        suspicious = [changed for changed in paths if not is_test_related(changed)]
        if suspicious:
            add(
                issues,
                "warning",
                "test-production-paths",
                "review possibly non-test paths in test.patch: " + ", ".join(suspicious),
            )
    else:
        forbidden = [changed for changed in paths if is_test_related(changed)]
        if forbidden:
            add(
                issues,
                "error",
                "solution-tests",
                "solution.patch modifies test/harness paths: " + ", ".join(forbidden),
            )


def check_patch_application(package: Path, repo: Path, issues: list[Issue]) -> None:
    if shutil.which("git") is None:
        add(issues, "warning", "git-missing", "git is unavailable; patch application was not checked")
        return
    try:
        subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--is-inside-work-tree"],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        add(issues, "error", "repo", f"--repo is not a usable Git checkout: {exc}")
        return

    with tempfile.TemporaryDirectory(prefix="olympus-validate-") as temp:
        clone = Path(temp) / "repo"
        commands = [
            ["git", "clone", "--quiet", "--no-hardlinks", str(repo), str(clone)],
            ["git", "-C", str(clone), "apply", "--check", str(package / "test.patch")],
            ["git", "-C", str(clone), "apply", str(package / "test.patch")],
            ["git", "-C", str(clone), "apply", "--check", str(package / "solution.patch")],
            ["git", "-C", str(clone), "apply", str(package / "solution.patch")],
            ["git", "-C", str(clone), "diff", "--check"],
        ]
        for command in commands:
            try:
                subprocess.run(command, check=True, capture_output=True, text=True)
            except (OSError, subprocess.CalledProcessError) as exc:
                detail = exc.stderr.strip() if isinstance(exc, subprocess.CalledProcessError) else str(exc)
                add(issues, "error", "patch-apply", f"command failed: {' '.join(command)}: {detail}")
                return


def validate(
    package: Path,
    repo: Path | None = None,
    ascii_only: bool = True,
    max_words: int = 500,
) -> list[Issue]:
    issues: list[Issue] = []
    if not package.is_dir():
        return [Issue("error", "package", f"not a directory: {package}")]
    present = {entry.name for entry in package.iterdir() if entry.is_file()}
    for required in CANONICAL_FILES:
        if required not in present:
            add(issues, "error", "missing-file", f"missing canonical file: {required}")
    extras = sorted(present - set(CANONICAL_FILES))
    if extras:
        add(issues, "warning", "extra-files", "extra files at package root: " + ", ".join(extras))
    if any(required not in present for required in CANONICAL_FILES):
        return issues

    check_problem(package, issues, ascii_only, max_words)
    check_dockerfile(package, issues)
    check_patch(package, "test.patch", issues)
    check_patch(package, "solution.patch", issues)
    for name in ("README.md", "test-design.md", "author-notes.md", "verification.md"):
        if not read_utf8(package / name, issues).strip():
            add(issues, "error", "empty-document", f"{name} is empty")
    if repo is not None:
        check_patch_application(package, repo, issues)
    return issues


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path)
    parser.add_argument("--repo", type=Path, help="pinned clean checkout used for sequential patch checks")
    parser.add_argument("--allow-unicode", action="store_true", help="require UTF-8 but not ASCII problem text")
    parser.add_argument("--max-problem-words", type=int, default=500, help="0 disables the word limit")
    parser.add_argument("--json", action="store_true", dest="json_output")
    args = parser.parse_args()

    issues = validate(
        args.package.resolve(),
        args.repo.resolve() if args.repo else None,
        ascii_only=not args.allow_unicode,
        max_words=args.max_problem_words,
    )
    if args.json_output:
        print(json.dumps([asdict(issue) for issue in issues], indent=2))
    elif issues:
        for issue in issues:
            print(f"{issue.severity.upper():7} {issue.code}: {issue.message}")
    else:
        print("OK: no structural issues found")
    errors = sum(issue.severity == "error" for issue in issues)
    warnings = sum(issue.severity == "warning" for issue in issues)
    if not args.json_output:
        print(f"Summary: {errors} error(s), {warnings} warning(s)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
