# Requirement-to-test matrix

Task version:

Pinned repository commit:

| ID | Requirement | Exact prompt sentence | Repository evidence | Public observation | Baseline behavior | Positive coverage | Adversarial mutant/probe | Reference implementation area | Fairness reviewed |
|---|---|---|---|---|---|---|---|---|---|
| R1 |  |  |  |  |  |  |  |  |  |

## Interaction matrix

| Behavior A | Behavior B | Expected combined result | Test/probe | Prompt support |
|---|---|---|---|---|
|  |  |  |  |  |

## Performance matrix

| Public operation | Announced shape/scale | Timed region | Semantic oracle | Reference median | Limit | Headroom |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## False-positive mutations

| Mutant | Plausibility | Violated requirement | Original suite passes | Focused probe fails | Reference passes | Added fairly |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
